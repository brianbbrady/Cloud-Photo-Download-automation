#!/bin/bash
# Mac Backup Script – Copy and Delete

SOURCE="$HOME/Pictures/iCloud Photos"
DEST="/Volumes/PhotoBackup/PhotosBackup"

mkdir -p "$DEST"
cp -R "$SOURCE"/* "$DEST" && rm -rf "$SOURCE"/*

echo "Copy + Delete completed on $(date)" >> "$DEST/backup-log.txt"
