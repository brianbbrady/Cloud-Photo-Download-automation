#!/bin/bash
# Mac Backup Script – Copy Only

SOURCE="$HOME/Pictures/iCloud Photos"
DEST="/Volumes/PhotoBackup/PhotosBackup"

mkdir -p "$DEST"
cp -R "$SOURCE"/* "$DEST"

echo "Backup completed on $(date)" >> "$DEST/backup-log.txt"
