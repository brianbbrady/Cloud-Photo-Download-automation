# Photo Backup Automation

This repository contains 4 simple scripts to automate the process of copying or backing up cloud photos to an external hard drive. Works for both Mac and Windows systems.

## Scripts

| Platform | Action           | File                      |
|----------|------------------|---------------------------|
| Mac      | Copy Only        | `mac/copy_only.sh`        |
| Mac      | Copy + Delete    | `mac/copy_and_delete.sh`  |
| Windows  | Copy Only        | `windows/copy_only.bat`   |
| Windows  | Copy + Delete    | `windows/copy_and_delete.bat` |

## Instructions

- Update the `SOURCE` and `DEST` paths in each script to match your setup.
- On Mac, mark scripts as executable with `chmod +x script.sh`
- On Windows, double-click `.bat` files to run.
- Logs are saved to your backup drive automatically.

## Safety Notice

Always confirm files are backed up successfully before enabling deletion.
